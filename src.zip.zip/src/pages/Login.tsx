import { useState } from "react";
import { auth } from "../firebase";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from "firebase/auth";

import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  Dumbbell,
  BookOpen,
  Target,
  Trophy,
  Flame,
  Moon,
} from "lucide-react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const login = async () => {
    try {
      setLoading(true);
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      alert(err.message);
    }
    setLoading(false);
  };

  const signup = async () => {
    try {
      setLoading(true);
      await createUserWithEmailAndPassword(auth, email, password);
      alert("🎉 Account Created Successfully");
    } catch (err: any) {
      alert(err.message);
    }
    setLoading(false);
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050816] flex items-center justify-center overflow-y-auto"
      style={{ padding: "40px 16px" }}
    >
      {/* Background Gradient */}
      <div className="fixed inset-0 bg-gradient-to-br from-[#050816] via-[#0b1128] to-[#031b25] pointer-events-none" />

      {/* Background Glows */}
      <div className="fixed -top-52 -left-52 h-[520px] w-[520px] rounded-full bg-purple-600/25 blur-[170px] pointer-events-none" />
      <div className="fixed -bottom-52 -right-52 h-[520px] w-[520px] rounded-full bg-cyan-500/20 blur-[170px] pointer-events-none" />

      {/* Floating Bubbles */}
      <div className="absolute top-12 left-10 w-5 h-5 rounded-full bg-cyan-400/40 animate-pulse"></div>
      <div className="absolute top-40 left-32 w-3 h-3 rounded-full bg-purple-400 animate-bounce"></div>
      <div className="absolute top-72 left-16 w-6 h-6 rounded-full bg-cyan-300/40 animate-pulse"></div>

      <div className="absolute top-24 right-12 w-4 h-4 rounded-full bg-indigo-400 animate-ping"></div>
      <div className="absolute top-64 right-40 w-5 h-5 rounded-full bg-cyan-400 animate-pulse"></div>
      <div className="absolute bottom-32 right-20 w-6 h-6 rounded-full bg-purple-500/50 animate-bounce"></div>

      <div className="absolute bottom-20 left-20 w-4 h-4 rounded-full bg-cyan-400 animate-pulse"></div>
      <div className="absolute bottom-56 left-52 w-3 h-3 rounded-full bg-pink-400 animate-ping"></div>
      <div className="absolute bottom-16 right-52 w-5 h-5 rounded-full bg-cyan-500 animate-bounce"></div>

      {/* Habit Watermark Icons */}
      <div className="absolute top-16 left-20 opacity-15 text-cyan-400 pointer-events-none hidden md:block">
        <Dumbbell size={70} />
      </div>
      <div className="absolute top-40 right-20 opacity-15 text-purple-400 pointer-events-none hidden md:block">
        <BookOpen size={70} />
      </div>
      <div className="absolute bottom-28 left-16 opacity-15 text-cyan-300 pointer-events-none hidden md:block">
        <Target size={70} />
      </div>
      <div className="absolute bottom-32 right-24 opacity-15 text-yellow-400 pointer-events-none hidden md:block">
        <Trophy size={70} />
      </div>
      <div className="absolute top-[45%] left-[8%] opacity-15 text-orange-400 pointer-events-none hidden md:block">
        <Flame size={60} />
      </div>
      <div className="absolute top-[55%] right-[10%] opacity-15 text-blue-300 pointer-events-none hidden md:block">
        <Moon size={60} />
      </div>

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-md my-auto">
        
        {/* SVG Logo */}
        <div className="flex justify-center" style={{ marginBottom: "20px" }}>
          <svg
            width="90"
            height="90"
            viewBox="0 0 120 120"
            className="drop-shadow-[0_0_25px_rgba(34,211,238,0.5)]"
          >
            <defs>
              <linearGradient id="habitGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#8b5cf6" />
                <stop offset="50%" stopColor="#6366f1" />
                <stop offset="100%" stopColor="#22d3ee" />
              </linearGradient>
            </defs>

            <circle
              cx="60"
              cy="60"
              r="46"
              fill="none"
              stroke="url(#habitGradient)"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray="250"
              strokeDashoffset="45"
            />

            <path
              d="M42 60 L56 74 L82 48"
              fill="none"
              stroke="white"
              strokeWidth="7"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>

        {/* Headings */}
        <p className="text-center tracking-[6px] uppercase text-cyan-400 text-xs font-semibold">
          Welcome Back
        </p>

        <h1
          className="text-center text-3xl font-black text-white tracking-tight"
          style={{ marginTop: "8px" }}
        >
          Habit Tracker
        </h1>

        <p
          className="text-center text-slate-400 text-sm leading-relaxed"
          style={{ marginTop: "12px", marginBottom: "28px" }}
        >
          Build better habits.<br />
          Stay consistent.<br />
          Become unstoppable.
        </p>

        {/* ================= EMAIL INPUT ================= */}
        <div className="relative" style={{ marginBottom: "18px" }}>
          <div
            className="absolute pointer-events-none z-10 text-slate-400 flex items-center justify-center"
            style={{ left: "16px", top: "0", bottom: "0" }}
          >
            <Mail size={20} />
          </div>

          <input
            type="email"
            placeholder="Enter your Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl text-white text-sm placeholder:text-slate-400 focus:outline-none focus:border-cyan-400 transition-all"
            style={{
              height: "54px",
              paddingLeft: "52px", // Fixed text overlap issue
              paddingRight: "16px",
            }}
          />
        </div>

        {/* ================= PASSWORD INPUT ================= */}
        <div className="relative" style={{ marginBottom: "18px" }}>
          <div
            className="absolute pointer-events-none z-10 text-slate-400 flex items-center justify-center"
            style={{ left: "16px", top: "0", bottom: "0" }}
          >
            <Lock size={20} />
          </div>

          <input
            type={showPassword ? "text" : "password"}
            placeholder="Enter your Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl text-white text-sm placeholder:text-slate-400 focus:outline-none focus:border-cyan-400 transition-all"
            style={{
              height: "54px",
              paddingLeft: "52px", // Fixed text overlap issue
              paddingRight: "52px",
            }}
          />

          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute text-slate-400 hover:text-cyan-300 transition flex items-center justify-center"
            style={{ right: "16px", top: "0", bottom: "0" }}
          >
            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
          </button>
        </div>

        {/* ================= OPTIONS ================= */}
        <div
          className="flex items-center justify-between text-xs"
          style={{ marginBottom: "24px", padding: "0 4px" }}
        >
          <label className="flex items-center gap-2 text-slate-400 cursor-pointer hover:text-slate-200">
            <input
              type="checkbox"
              className="accent-cyan-500 w-4 h-4 rounded cursor-pointer"
            />
            Remember Me
          </label>

          <button
            type="button"
            className="text-cyan-400 hover:text-cyan-300 transition font-medium"
          >
            Forgot Password?
          </button>
        </div>

        {/* ================= LOGIN BUTTON ================= */}
        <button
          onClick={login}
          disabled={loading}
          className="w-full rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-500 font-bold text-white text-base shadow-[0_10px_35px_rgba(34,211,238,0.25)] hover:scale-[1.01] active:scale-95 transition-all duration-300 disabled:opacity-50"
          style={{ height: "52px" }}
        >
          {loading ? "Signing In..." : "Login"}
        </button>

        {/* Divider */}
        <div
          className="flex items-center gap-4"
          style={{ marginTop: "24px", marginBottom: "24px" }}
        >
          <div className="flex-1 h-px bg-slate-800"></div>
          <span className="text-slate-500 text-xs font-semibold tracking-wider uppercase">
            OR
          </span>
          <div className="flex-1 h-px bg-slate-800"></div>
        </div>

        {/* ================= CREATE ACCOUNT BUTTON ================= */}
        <button
          onClick={signup}
          disabled={loading}
          className="w-full rounded-2xl border border-cyan-400/50 bg-white/5 backdrop-blur-xl text-cyan-300 font-semibold text-base hover:bg-cyan-500/10 hover:border-cyan-300 hover:text-white transition-all duration-300 disabled:opacity-50"
          style={{ height: "52px" }}
        >
          Create Account
        </button>

        {/* ================= MOTIVATION CARD ================= */}
        <div
          className="rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 p-5 text-center"
          style={{ marginTop: "28px" }}
        >
          <div className="flex justify-center text-3xl" style={{ marginBottom: "8px" }}>
            🔥
          </div>
          <h3 className="text-white text-base font-bold" style={{ marginBottom: "6px" }}>
            Today's Motivation
          </h3>
          <p className="text-slate-400 text-xs leading-relaxed">
            Success doesn't come from what you do occasionally.<br />
            It comes from what you do consistently.
          </p>
        </div>

        {/* ================= DAILY HABITS ================= */}
        <div
          className="grid grid-cols-4 gap-3"
          style={{ marginTop: "28px", marginBottom: "28px" }}
        >
          <div className="flex flex-col items-center">
            <div className="h-14 w-14 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:scale-105 transition-all">
              <Dumbbell className="text-cyan-400" size={24} />
            </div>
            <span className="text-slate-400 text-[11px]" style={{ marginTop: "8px" }}>
              Workout
            </span>
          </div>

          <div className="flex flex-col items-center">
            <div className="h-14 w-14 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:scale-105 transition-all">
              <BookOpen className="text-purple-400" size={24} />
            </div>
            <span className="text-slate-400 text-[11px]" style={{ marginTop: "8px" }}>
              Study
            </span>
          </div>

          <div className="flex flex-col items-center">
            <div className="h-14 w-14 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:scale-105 transition-all">
              <Target className="text-pink-400" size={24} />
            </div>
            <span className="text-slate-400 text-[11px]" style={{ marginTop: "8px" }}>
              Goals
            </span>
          </div>

          <div className="flex flex-col items-center">
            <div className="h-14 w-14 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:scale-105 transition-all">
              <Moon className="text-blue-400" size={24} />
            </div>
            <span className="text-slate-400 text-[11px]" style={{ marginTop: "8px" }}>
              Sleep
            </span>
          </div>
        </div>

        {/* ================= FOOTER ================= */}
        <div className="text-center" style={{ paddingTop: "8px" }}>
          <p className="text-slate-500 text-xs">
            Secure Authentication using Firebase 🔐
          </p>
          <p className="text-slate-600 text-[11px]" style={{ marginTop: "4px" }}>
            © 2026 Habit Tracker • Designed by Rahul Singh
          </p>
        </div>

      </div>
    </div>
  );
}